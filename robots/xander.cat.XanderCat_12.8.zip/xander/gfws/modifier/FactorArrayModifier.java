package xander.gfws.modifier;

import xander.core.track.Wave;

public interface FactorArrayModifier {

	public void modify(double[] array, Wave wave);
	
}
