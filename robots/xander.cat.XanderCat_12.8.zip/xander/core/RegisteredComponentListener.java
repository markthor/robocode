package xander.core;

public interface RegisteredComponentListener {

	public void componentRegistered(Component component);
}
