package xander.core.event;

import robocode.SkippedTurnEvent;

public interface SkippedTurnListener {

	public void onSkippedTurn(SkippedTurnEvent event);
}
