package xander.core.event;

public interface OpponentGunListener {

	public void opponentGunFired(OpponentGunFiredEvent event);
}
