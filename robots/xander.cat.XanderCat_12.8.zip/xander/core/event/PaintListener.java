package xander.core.event;

import java.awt.Graphics2D;

public interface PaintListener {

	public void onPaint(Graphics2D g);
}
