package xander.core.event;

public interface RoundBeginListener {

	public void onRoundBegin();
}
