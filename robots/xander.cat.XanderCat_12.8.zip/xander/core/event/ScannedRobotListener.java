package xander.core.event;

import robocode.ScannedRobotEvent;

public interface ScannedRobotListener {
	
	public void onScannedRobot(ScannedRobotEvent event);
}
