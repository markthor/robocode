package xander.core.math;

public interface Function {

	public double getY(double x);
}
